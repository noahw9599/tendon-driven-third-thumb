V2 bench assembly, revision 23 with the repair 17 yaw rotor.
STEP part bodies in millimeters. The assembly reference is provided separately.
P09/P10 are one shared part geometry; two copies are used. S07 is retired.
