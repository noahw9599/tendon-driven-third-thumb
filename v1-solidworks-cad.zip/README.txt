V1 reference assembly: previewAssembly.SLDASM.
CHAP_V0_Joint and CHAP_V0_Thumb are the installed hardware-fit revisions. They were never inserted into this reference assembly.
My_ElectronicsCaseBase is the modified holder.
Upstream credit: https://github.com/laxmangordon/Third-Thumb-Project
See LICENSE-UPSTREAM-MIT.txt for upstream copyright and permission notice.
